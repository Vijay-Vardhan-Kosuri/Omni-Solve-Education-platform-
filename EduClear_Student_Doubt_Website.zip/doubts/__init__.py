# doubts app package initialization
