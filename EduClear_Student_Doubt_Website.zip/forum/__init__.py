# forum app package initialization
