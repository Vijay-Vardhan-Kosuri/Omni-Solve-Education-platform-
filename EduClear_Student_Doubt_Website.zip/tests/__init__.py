# tests package initialization
